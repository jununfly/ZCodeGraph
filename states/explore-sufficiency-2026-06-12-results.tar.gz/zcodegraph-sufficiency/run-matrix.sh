#!/usr/bin/env bash
set -u

ROOT="/Users/bilibili/Documents/workspace/jununfly/ZCodeGraph"
OUT_ROOT="/tmp/zcodegraph-sufficiency"
CG_BIN="/tmp/zcodegraph-dev"

run_one() {
  local repo_key="$1"
  local repo_path="$2"
  local prompt_id="$3"
  local question="$4"
  local run_no="$5"
  local out_dir="$OUT_ROOT/$repo_key/$prompt_id/run$run_no"

  mkdir -p "$out_dir"
  {
    echo "repo_key=$repo_key"
    echo "repo_path=$repo_path"
    echo "prompt_id=$prompt_id"
    echo "run=$run_no"
    echo "question=$question"
    echo "started_at=$(date -Iseconds)"
  } > "$out_dir/metadata.env"

  echo "===== START $repo_key $prompt_id run$run_no $(date -Iseconds) ====="
  AGENT_EVAL_OUT="$out_dir" CG_BIN="$CG_BIN" \
    bash "$ROOT/scripts/agent-eval/run-all.sh" "$repo_path" "$question" headless
  local status=$?
  echo "finished_at=$(date -Iseconds)" >> "$out_dir/metadata.env"
  echo "exit_status=$status" >> "$out_dir/metadata.env"
  echo "===== END $repo_key $prompt_id run$run_no status=$status $(date -Iseconds) ====="
  return "$status"
}

run_repo_zcg() {
  local repo="/Users/bilibili/Documents/workspace/jununfly/ZCodeGraph"
  run_one zcg "$repo" ZCG-1 'How does a `zcodegraph_explore` request become rendered markdown? Use this symbol bag: `handleExplore plan ExplorePlan render`.' 1
  run_one zcg "$repo" ZCG-1 'How does a `zcodegraph_explore` request become rendered markdown? Use this symbol bag: `handleExplore plan ExplorePlan render`.' 2
  run_one zcg "$repo" ZCG-2 'How does indexing source files reach database node writes? Use this symbol bag: `runIndex CodeGraph.indexAll ExtractionOrchestrator.indexAll ParseStage QueryBuilder.insertNode`.' 1
  run_one zcg "$repo" ZCG-2 'How does indexing source files reach database node writes? Use this symbol bag: `runIndex CodeGraph.indexAll ExtractionOrchestrator.indexAll ParseStage QueryBuilder.insertNode`.' 2
  run_one zcg "$repo" ZCG-3 'How does reference resolution run synthesizers and persist heuristic edges? Use this symbol bag: `ReferenceResolver.resolveAll createSynthesizerRegistry registerFullGraphSynthesizers executeFullGraphSynthesizers QueryBuilder.insertEdge`.' 1
  run_one zcg "$repo" ZCG-3 'How does reference resolution run synthesizers and persist heuristic edges? Use this symbol bag: `ReferenceResolver.resolveAll createSynthesizerRegistry registerFullGraphSynthesizers executeFullGraphSynthesizers QueryBuilder.insertEdge`.' 2
}

run_repo_excalidraw() {
  local repo="/tmp/codegraph-corpus/excalidraw"
  run_one excalidraw "$repo" EX-1 'How does updating an element re-render the canvas on screen? Use this symbol bag: `mutateElement triggerUpdate triggerRender render StaticCanvas renderStaticScene`.' 1
  run_one excalidraw "$repo" EX-1 'How does updating an element re-render the canvas on screen? Use this symbol bag: `mutateElement triggerUpdate triggerRender render StaticCanvas renderStaticScene`.' 2
  run_one excalidraw "$repo" EX-2 'How does a `Scene.onUpdate` subscription reach React render? Use this symbol bag: `Scene.onUpdate triggerUpdate triggerRender render StaticCanvas`.' 1
  run_one excalidraw "$repo" EX-2 'How does a `Scene.onUpdate` subscription reach React render? Use this symbol bag: `Scene.onUpdate triggerUpdate triggerRender render StaticCanvas`.' 2
  run_one excalidraw "$repo" EX-3 'How does `StaticCanvas` render elements onto the canvas? Use this symbol bag: `StaticCanvas renderStaticScene _renderStaticScene drawElementOnCanvas renderElement`.' 1
  run_one excalidraw "$repo" EX-3 'How does `StaticCanvas` render elements onto the canvas? Use this symbol bag: `StaticCanvas renderStaticScene _renderStaticScene drawElementOnCanvas renderElement`.' 2
}

run_repo_django() {
  local repo="/tmp/codegraph-corpus/django"
  run_one django "$repo" DJ-1 'How does evaluating a `QuerySet` reach SQL execution? Use this symbol bag: `QuerySet._fetch_all ModelIterable.__iter__ SQLCompiler.execute_sql`.' 1
  run_one django "$repo" DJ-1 'How does evaluating a `QuerySet` reach SQL execution? Use this symbol bag: `QuerySet._fetch_all ModelIterable.__iter__ SQLCompiler.execute_sql`.' 2
  run_one django "$repo" DJ-2 'How does iterating a `QuerySet` reach compiler results? Use this symbol bag: `QuerySet.iterator QuerySet._iterator ModelIterable.__iter__ SQLCompiler.execute_sql`.' 1
  run_one django "$repo" DJ-2 'How does iterating a `QuerySet` reach compiler results? Use this symbol bag: `QuerySet.iterator QuerySet._iterator ModelIterable.__iter__ SQLCompiler.execute_sql`.' 2
  run_one django "$repo" DJ-3 'How does a `QuerySet` build SQL through the compiler? Use this symbol bag: `Query.get_compiler SQLCompiler.as_sql SQLCompiler.execute_sql`.' 1
  run_one django "$repo" DJ-3 'How does a `QuerySet` build SQL through the compiler? Use this symbol bag: `Query.get_compiler SQLCompiler.as_sql SQLCompiler.execute_sql`.' 2
}

mkdir -p "$OUT_ROOT"
echo "matrix_started_at=$(date -Iseconds)"
run_repo_zcg
run_repo_excalidraw
run_repo_django
echo "matrix_finished_at=$(date -Iseconds)"
