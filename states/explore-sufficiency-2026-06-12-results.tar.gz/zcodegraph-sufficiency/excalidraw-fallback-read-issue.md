## Parent

Parent issue: #40

## What to build

Improve `zcodegraph_explore` sufficiency for the Excalidraw React update flow so the agent does not need to read `App.tsx` after the Flow section has already surfaced the `Scene.onUpdate` callback wiring.

The 2026-06-12 Explore sufficiency matrix found that Excalidraw WITH-ZCodeGraph runs mostly displaced generic Read/Grep fallback, but two runs still opened `App.tsx` to confirm the `Scene.onUpdate(this.triggerRender)` registration. That means the graph found the right dynamic boundary, but the answer was not self-contained enough for the agent to stop.

This slice should make the existing tool output carry the callback registration evidence clearly enough that EX-1 and EX-2 can complete without generic file reads, without relying on new agent instructions or a different tool choice.

## Acceptance criteria

- [ ] Re-run the Excalidraw EX-1 prompt with ZCodeGraph enabled for at least 2 runs and record 0 generic Read/Grep fallback calls.
- [ ] Re-run the Excalidraw EX-2 prompt with ZCodeGraph enabled for at least 2 runs and record 0 generic Read/Grep fallback calls.
- [ ] The `zcodegraph_explore` Flow or evidence output makes the `Scene.onUpdate` callback registration and `triggerRender` target explicit enough that an agent can explain the path without opening `App.tsx`.
- [ ] The change is covered by deterministic probe or integration coverage that fails before the fix and passes after it.
- [ ] The fix does not depend on changing MCP server instructions, tool descriptions, or asking the agent to choose a different tool.
- [ ] No regression in the Excalidraw EX-3 prompt: it still completes with 0 generic Read/Grep fallback calls in at least 2 WITH-ZCodeGraph runs.

## Blocked by

None - can start immediately
