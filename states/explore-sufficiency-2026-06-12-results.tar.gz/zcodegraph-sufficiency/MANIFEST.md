# Explore Sufficiency Evaluation Result Bundle

This bundle corresponds to:

- `docs/benchmarks/explore-sufficiency-2026-06-11.md`

It contains the raw and summarized output from the 2026-06-12 external Claude CLI evaluation matrix for issues #39, #40, and #41.

## Contents

- `summary.md` — human-readable rollup table and Read/Grep fallback classification.
- `summary.json` — structured per-run metrics.
- `zcg/` — raw ZCodeGraph self-sufficiency run logs.
- `excalidraw/` — raw Excalidraw Explore sufficiency run logs.
- `django/` — raw Django Explore sufficiency run logs.
- `run-matrix.sh` — temporary driver used to execute the matrix.
- `excalidraw-fallback-read-issue.md` — issue body used to create follow-up issue #43.

## Matrix Shape

- 3 repos: ZCodeGraph, Excalidraw, Django.
- 3 flow prompts per repo.
- 2 runs per prompt.
- 2 arms per run: WITH ZCodeGraph and WITHOUT ZCodeGraph.
- 36 total agent-arm logs.

## Notes

- The benchmark source template and acceptance criteria are in `docs/benchmarks/explore-sufficiency-2026-06-11.md`.
- Raw logs were originally written under `/tmp/zcodegraph-sufficiency/`.
- Generic Read and grep/find Bash calls were classified as fallback for these flow-only prompts unless otherwise noted in `summary.md`.
